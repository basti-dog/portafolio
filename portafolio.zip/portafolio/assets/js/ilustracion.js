document.addEventListener("DOMContentLoaded", function () {
  const section = document.querySelector(".illustration-projects-section");
  const grid = document.querySelector(".illustration-grid");
  const items = Array.from(document.querySelectorAll("[data-project]"));
  const filters = Array.from(document.querySelectorAll("[data-filter]"));
  const emptyMessage = document.querySelector(".illustration-empty-message");

  const preview = document.querySelector(".illustration-preview");
  const previewBackdrop = document.querySelector(".illustration-preview-backdrop");
  const previewPanel = document.querySelector(".illustration-preview-panel");
  const previewImageWrap = document.querySelector(".illustration-preview-image-wrap");
  const previewImage = document.querySelector(".illustration-preview-image");
  const previewTitle = document.querySelector(".illustration-preview-title");
  const previewCategory = document.querySelector(".illustration-preview-category");
  const previewYear = document.querySelector(".illustration-preview-year");
  const previewDescription = document.querySelector(".illustration-preview-description");
  const closeButtons = Array.from(document.querySelectorAll("[data-preview-close]"));

  if (!section || !grid || !items.length || !preview) return;

  const hasGSAP = typeof window.gsap !== "undefined";
  let activeItem = null;
  let isAnimating = false;
  let lastFocusedElement = null;

  function getVisibleItems() {
    return items.filter(function (item) {
      return !item.hidden;
    });
  }

  function updateEmptyState() {
    if (!emptyMessage) return;
    emptyMessage.hidden = getVisibleItems().length !== 0;
  }

  function applyFilter(filterName) {
    if (isAnimating || preview.classList.contains("is-open")) return;

    filters.forEach(function (button) {
      button.classList.toggle("is-active", button.dataset.filter === filterName);
    });

    const visibleBefore = getVisibleItems();

    if (!hasGSAP) {
      items.forEach(function (item) {
        const categories = (item.dataset.categories || "").split(" ");
        item.hidden = filterName !== "all" && !categories.includes(filterName);
      });
      updateEmptyState();
      return;
    }

    isAnimating = true;

    gsap.to(visibleBefore, {
      opacity: 0,
      y: -18,
      scale: 0.97,
      duration: 0.22,
      stagger: 0.025,
      ease: "power1.in",
      onComplete: function () {
        items.forEach(function (item) {
          const categories = (item.dataset.categories || "").split(" ");
          item.hidden = filterName !== "all" && !categories.includes(filterName);
        });

        updateEmptyState();

        const visibleAfter = getVisibleItems();
        gsap.set(visibleAfter, { opacity: 0, y: 26, scale: 0.96 });

        gsap.to(visibleAfter, {
          opacity: 1,
          y: 0,
          scale: 1,
          duration: 0.55,
          stagger: 0.05,
          ease: "power2.out",
          clearProps: "transform,opacity",
          onComplete: function () {
            isAnimating = false;
          }
        });
      }
    });
  }

  function fillPreview(item) {
    const img = item.querySelector("img");

    previewImage.src = item.dataset.full || (img ? img.src : "");
    previewImage.alt = item.dataset.title || "Proyecto de ilustración";
    previewTitle.textContent = item.dataset.title || "Proyecto";
    previewCategory.textContent = item.dataset.category || "Ilustración";
    previewYear.textContent = item.dataset.year || "";
    previewDescription.textContent = item.dataset.description || "";
  }

  function openPreview(item) {
    if (isAnimating || preview.classList.contains("is-open")) return;

    activeItem = item;
    lastFocusedElement = document.activeElement;
    fillPreview(item);

    preview.classList.add("is-open");
    preview.setAttribute("aria-hidden", "false");
    document.body.classList.add("illustration-preview-open");
    grid.classList.add("is-inactive");

    if (!hasGSAP) {
      previewBackdrop.style.opacity = "1";
      previewPanel.style.opacity = "1";
      previewPanel.style.transform = "translateY(0)";
      return;
    }

    isAnimating = true;
    const visibleItems = getVisibleItems();
    const activeIndex = visibleItems.indexOf(item);

    gsap.timeline({
      defaults: { overwrite: true },
      onComplete: function () {
        isAnimating = false;
        const closeButton = preview.querySelector(".illustration-preview-close");
        if (closeButton) closeButton.focus();
      }
    })
      .to(visibleItems, {
        y: function (index) {
          return -700 - Math.abs(index - activeIndex) * 55;
        },
        opacity: 0,
        rotationX: function () {
          return gsap.utils.random(-8, 8);
        },
        rotationY: function () {
          return gsap.utils.random(-8, 8);
        },
        duration: 0.9,
        stagger: {
          each: 0.035,
          from: activeIndex
        },
        ease: "expo.inOut"
      }, 0)
      .to(previewBackdrop, {
        opacity: 1,
        duration: 0.45,
        ease: "power2.out"
      }, 0.3)
      .fromTo(previewPanel, {
        opacity: 0,
        y: 100
      }, {
        opacity: 1,
        y: 0,
        duration: 0.75,
        ease: "expo.out"
      }, 0.42)
      .fromTo(previewImageWrap, {
        opacity: 0,
        y: 80,
        scale: 0.92,
        rotationX: -8
      }, {
        opacity: 1,
        y: 0,
        scale: 1,
        rotationX: 0,
        duration: 0.9,
        ease: "expo.out"
      }, 0.52)
      .fromTo([
        previewCategory,
        previewTitle,
        previewYear,
        previewDescription,
        preview.querySelector(".illustration-preview-link")
      ], {
        opacity: 0,
        y: 34
      }, {
        opacity: 1,
        y: 0,
        duration: 0.65,
        stagger: 0.07,
        ease: "power3.out"
      }, 0.62);
  }

  function closePreview() {
    if (isAnimating || !preview.classList.contains("is-open")) return;

    const visibleItems = getVisibleItems();

    if (!hasGSAP) {
      preview.classList.remove("is-open");
      preview.setAttribute("aria-hidden", "true");
      document.body.classList.remove("illustration-preview-open");
      grid.classList.remove("is-inactive");
      if (lastFocusedElement) lastFocusedElement.focus();
      return;
    }

    isAnimating = true;

    gsap.timeline({
      defaults: { overwrite: true },
      onComplete: function () {
        preview.classList.remove("is-open");
        preview.setAttribute("aria-hidden", "true");
        document.body.classList.remove("illustration-preview-open");
        grid.classList.remove("is-inactive");

        gsap.set([previewPanel, previewBackdrop, previewImageWrap], {
          clearProps: "all"
        });

        isAnimating = false;
        if (lastFocusedElement) lastFocusedElement.focus();
      }
    })
      .to(previewPanel, {
        opacity: 0,
        y: 80,
        duration: 0.48,
        ease: "power2.in"
      }, 0)
      .to(previewBackdrop, {
        opacity: 0,
        duration: 0.42,
        ease: "power2.in"
      }, 0.05)
      .set(visibleItems, {
        opacity: 0,
        y: 90,
        rotationX: 0,
        rotationY: 0
      }, 0.2)
      .to(visibleItems, {
        opacity: 1,
        y: 0,
        rotationX: 0,
        rotationY: 0,
        duration: 0.75,
        stagger: 0.045,
        ease: "expo.out",
        clearProps: "transform,opacity"
      }, 0.34);
  }

  function applyTilt(item) {
    const media = item.querySelector(".illustration-grid-media");
    if (!media || !hasGSAP || window.matchMedia("(pointer: coarse)").matches) return;

    item.addEventListener("mousemove", function (event) {
      if (preview.classList.contains("is-open")) return;

      const rect = item.getBoundingClientRect();
      const x = (event.clientX - rect.left) / rect.width - 0.5;
      const y = (event.clientY - rect.top) / rect.height - 0.5;

      gsap.to(media, {
        rotationY: x * 9,
        rotationX: y * -9,
        x: x * 8,
        y: y * 8,
        transformPerspective: 900,
        duration: 0.35,
        ease: "power2.out"
      });
    });

    item.addEventListener("mouseleave", function () {
      gsap.to(media, {
        rotationY: 0,
        rotationX: 0,
        x: 0,
        y: 0,
        duration: 0.55,
        ease: "power3.out"
      });
    });
  }

  filters.forEach(function (button) {
    button.addEventListener("click", function () {
      applyFilter(button.dataset.filter || "all");
    });
  });

  items.forEach(function (item) {
    item.addEventListener("click", function () {
      openPreview(item);
    });

    applyTilt(item);
  });

  closeButtons.forEach(function (button) {
    button.addEventListener("click", closePreview);
  });

  document.addEventListener("keydown", function (event) {
    if (event.key === "Escape") closePreview();
  });
});
