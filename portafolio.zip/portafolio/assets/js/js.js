document.addEventListener("DOMContentLoaded", function () {
  /* ============================================================
     PREFERENCIAS DE MOVIMIENTO
     ============================================================ */

  const prefersReducedMotion = window.matchMedia(
    "(prefers-reduced-motion: reduce)"
  ).matches;

  /* ============================================================
     LENIS / SCROLL SUAVE
     ============================================================ */

  let lenis = null;

  if (typeof Lenis !== "undefined" && !prefersReducedMotion) {
    lenis = new Lenis({
      duration: 1.25,
      smoothWheel: true,
      smoothTouch: false,
      wheelMultiplier: 0.9,
      touchMultiplier: 1.2,
      easing: function (t) {
        return Math.min(1, 1.001 - Math.pow(2, -10 * t));
      },
    });

    function raf(time) {
      lenis.raf(time);
      requestAnimationFrame(raf);
    }

    requestAnimationFrame(raf);
  }
/* ============================================================
   GSAP + SPLITTING / MANIFIESTO
   ============================================================ */

if (
  typeof gsap !== "undefined" &&
  typeof ScrollTrigger !== "undefined" &&
  typeof Splitting !== "undefined"
) {
  gsap.registerPlugin(ScrollTrigger);

  const manifestoEffect = document.querySelector("[data-effect25]");

  if (manifestoEffect) {
    Splitting({
      target: manifestoEffect,
      by: "chars",
    });

    const manifestoSection =
      manifestoEffect.closest(".manifesto-section");

    const manifestoChars =
      manifestoEffect.querySelectorAll(".char");

    gsap.set(manifestoChars, {
      transformOrigin: "50% 100%",
      scaleY: 0,
      opacity: 1,
    });

    gsap.to(manifestoChars, {
      scaleY: 1,
      opacity: 1,
      ease: "power3.in",
      stagger: 0.050,

      scrollTrigger: {
        trigger: manifestoSection,
        start: "top top",
        end: "+=350%",
        scrub: 1,
        pin: manifestoSection,
        pinSpacing: true,
        anticipatePin: 1,
        invalidateOnRefresh: true,
      },
    });

    if (lenis) {
      lenis.on("scroll", ScrollTrigger.update);
    }

    window.addEventListener("load", function () {
      ScrollTrigger.refresh();
    });
  }
}
/* ============================================================
   GSAP + SPLITTING / PROCESO — EFECTO 8
   ============================================================ */

if (
  typeof gsap !== "undefined" &&
  typeof ScrollTrigger !== "undefined" &&
  typeof Splitting !== "undefined"
) {
  gsap.registerPlugin(ScrollTrigger);

  const processTitles = document.querySelectorAll("[data-effect8]");

  if (processTitles.length > 0) {
    Splitting({
      target: "[data-effect8]",
      by: "chars",
    });

    const lettersAndSymbols = [
      "a", "b", "c", "d", "e", "f", "g", "h",
      "i", "j", "k", "l", "m", "n", "o", "p",
      "q", "r", "s", "t", "u", "v", "w", "x",
      "y", "z", "!", "@", "#", "$", "%", "^",
      "&", "*", "-", "_", "+", "=", ";", ":",
      "<", ">", ","
    ];

    function getRandomCharacter() {
      const randomIndex = Math.floor(
        Math.random() * lettersAndSymbols.length
      );

      return lettersAndSymbols[randomIndex];
    }

    processTitles.forEach(function (title) {
      const chars = title.querySelectorAll(".char");

      const originalCharacters = Array.from(chars).map(function (char) {
        return char.textContent;
      });

      function resetTitle() {
        chars.forEach(function (char, index) {
          char.textContent = originalCharacters[index];
          gsap.set(char, {
            opacity: 1,
          });
        });
      }

      function playScrambleEffect() {
        resetTitle();

        const timeline = gsap.timeline();

        chars.forEach(function (char, position) {
          const originalCharacter = originalCharacters[position];

          timeline.fromTo(
            char,
            {
              opacity: 0,
            },
            {
              opacity: 1,
              duration: 0.04,
              repeat: 3,
              repeatDelay: 0.025,
              delay: position * 0.055,

              onStart: function () {
                char.textContent = getRandomCharacter();
              },

              onRepeat: function () {
                char.textContent = getRandomCharacter();
              },

              onComplete: function () {
                char.textContent = originalCharacter;
              },
            },
            0
          );
        });
      }

      ScrollTrigger.create({
        trigger: title,
        start: "top 88%",

        onEnter: function () {
          playScrambleEffect();
        },

        onEnterBack: function () {
          playScrambleEffect();
        },

        onLeaveBack: function () {
          resetTitle();
        },
      });
    });

    window.addEventListener("load", function () {
      ScrollTrigger.refresh();
    });
  }
}
  /* ============================================================
     SCROLL / HEADER / HERO
     ============================================================ */

  let lastScrollY = window.scrollY;

  function handleScrollStates() {
    const y = window.scrollY;
    const scrollingDown = y > lastScrollY;

   if (y > 35) {
  document.body.classList.add("scrolled");
} else {
  document.body.classList.remove("scrolled");
}
    if (y > 80) {
      document.body.classList.add("content-visible");
    } else {
      document.body.classList.remove("content-visible");
    }

    const menuIsOpen = document.body.classList.contains("mobile-menu-open");
    const modalIsOpen = document.body.classList.contains("modal-open");

    if (scrollingDown && y > 260 && !menuIsOpen && !modalIsOpen) {
      document.body.classList.add("header-hidden");
    } else {
      document.body.classList.remove("header-hidden");
    }

    lastScrollY = y;
  }

  window.addEventListener("scroll", handleScrollStates, { passive: true });
  handleScrollStates();

  

  /* ============================================================
     MODAL PERFIL
     ============================================================ */

  const profileModal = document.querySelector("#profileModal");
  const openProfileButtons = document.querySelectorAll(
    "[data-open-profile], [data-open-about]"
  );
  const closeProfileButtons = document.querySelectorAll("[data-close-profile]");

  let lastFocusedElement = null;

  function openProfileModal() {
    if (!profileModal) return;

    closeMobileMenu();

    lastFocusedElement = document.activeElement;

    profileModal.classList.add("open");
    profileModal.setAttribute("aria-hidden", "false");

    document.body.classList.add("modal-open");
    document.body.classList.remove("header-hidden");

    if (lenis) {
      lenis.stop();
    }

    const modalScroll = profileModal.querySelector(".profile-modal-scroll");

    if (modalScroll) {
      modalScroll.scrollTop = 0;
    }

    const closeButton = profileModal.querySelector("[data-close-profile]");

    if (closeButton) {
      closeButton.focus();
    }
  }

  function closeProfileModal() {
    if (!profileModal) return;

    profileModal.classList.remove("open");
    profileModal.setAttribute("aria-hidden", "true");

    document.body.classList.remove("modal-open");

    if (!document.body.classList.contains("mobile-menu-open") && lenis) {
      lenis.start();
    }

    if (lastFocusedElement && typeof lastFocusedElement.focus === "function") {
      lastFocusedElement.focus();
    }
  }

  openProfileButtons.forEach(function (button) {
    button.addEventListener("click", openProfileModal);
  });

  closeProfileButtons.forEach(function (button) {
    button.addEventListener("click", closeProfileModal);
  });

  if (profileModal) {
    profileModal.addEventListener("click", function (event) {
      if (event.target === profileModal) {
        closeProfileModal();
      }
    });
  }

  /* ============================================================
     MENÚ MOBILE
     ============================================================ */

  const mobileMenuPanel = document.querySelector("#mobileMenuPanel");
  const mobileMenuButton = document.querySelector("[data-mobile-menu-open]");
  const mobileMenuLinks = document.querySelectorAll(".mobile-menu-links a");
  const mobileMenuBlur = document.querySelector(".mobile-menu-blur");

  function openMobileMenu() {
    if (!mobileMenuPanel || !mobileMenuButton) return;

    closeProfileModal();

    document.body.classList.add("mobile-menu-open");
    document.body.classList.remove("header-hidden");

    mobileMenuPanel.setAttribute("aria-hidden", "false");
    mobileMenuButton.setAttribute("aria-expanded", "true");
    mobileMenuButton.setAttribute("aria-label", "Cerrar menú");

    if (lenis) {
      lenis.stop();
    }
  }

  function closeMobileMenu() {
    if (!mobileMenuPanel || !mobileMenuButton) return;

    document.body.classList.remove("mobile-menu-open");

    mobileMenuPanel.setAttribute("aria-hidden", "true");
    mobileMenuButton.setAttribute("aria-expanded", "false");
    mobileMenuButton.setAttribute("aria-label", "Abrir menú");

    if (!document.body.classList.contains("modal-open") && lenis) {
      lenis.start();
    }
  }

  function toggleMobileMenu() {
    if (document.body.classList.contains("mobile-menu-open")) {
      closeMobileMenu();
    } else {
      openMobileMenu();
    }
  }

  if (mobileMenuButton) {
    mobileMenuButton.addEventListener("click", toggleMobileMenu);
  }

  if (mobileMenuBlur) {
    mobileMenuBlur.addEventListener("click", closeMobileMenu);
  }

  mobileMenuLinks.forEach(function (link) {
    link.addEventListener("click", closeMobileMenu);
  });

  /* ============================================================
     MODELO 3D / MOVIMIENTO SUAVE
     ============================================================ */

  const brandModel = document.querySelector("#brandModel");

  let modelTargetX = 28;
  let modelTargetY = 72;
  let modelCurrentX = 28;
  let modelCurrentY = 72;

  let modelMouseX = 0;
  let modelMouseY = 0;

  function updateBrandModelTarget() {
    if (!brandModel) return;

    const scrollProgress = Math.min(window.scrollY / 900, 1);

    modelTargetX = 28 + scrollProgress * 26 + modelMouseX;
    modelTargetY = 72 - scrollProgress * 8 + modelMouseY;
  }

  function animateBrandModel() {
    if (brandModel && !prefersReducedMotion) {
      modelCurrentX += (modelTargetX - modelCurrentX) * 0.05;
      modelCurrentY += (modelTargetY - modelCurrentY) * 0.05;

      brandModel.cameraOrbit =
        modelCurrentX.toFixed(2) +
        "deg " +
        modelCurrentY.toFixed(2) +
        "deg 16m";
    }

    requestAnimationFrame(animateBrandModel);
  }

  window.addEventListener("scroll", updateBrandModelTarget, { passive: true });

  window.addEventListener("mousemove", function (event) {
    if (!brandModel) return;

    const isMobile = window.innerWidth <= 640;

    if (isMobile || prefersReducedMotion) return;

    const x = event.clientX / window.innerWidth - 0.5;
    const y = event.clientY / window.innerHeight - 0.5;

    modelMouseX = x * 2.2;
    modelMouseY = y * 1.2;

    updateBrandModelTarget();
  });

  updateBrandModelTarget();
  animateBrandModel();



  /* ============================================================
     MODAL CONTACTO
     ============================================================ */

  const contactModal = document.querySelector("#contactModal");
  const openContactButtons = document.querySelectorAll("[data-open-contact]");
  const closeContactButtons = document.querySelectorAll("[data-close-contact]");
  const contactForm = document.querySelector("#contactForm");
  let lastContactFocus = null;

  function openContactModal() {
    if (!contactModal) return;
    closeMobileMenu();
    closeProfileModal();
    lastContactFocus = document.activeElement;
    contactModal.classList.add("open");
    contactModal.setAttribute("aria-hidden", "false");
    document.body.classList.add("modal-open");
    document.body.classList.remove("header-hidden");
    if (lenis) lenis.stop();
    const firstField = contactModal.querySelector("input, select, textarea");
    window.setTimeout(function () { if (firstField) firstField.focus(); }, 50);
  }

  function closeContactModal() {
    if (!contactModal) return;
    contactModal.classList.remove("open");
    contactModal.setAttribute("aria-hidden", "true");
    document.body.classList.remove("modal-open");
    if (!document.body.classList.contains("mobile-menu-open") && lenis) lenis.start();
    if (lastContactFocus && typeof lastContactFocus.focus === "function") lastContactFocus.focus();
  }

  openContactButtons.forEach(function (button) {
    button.addEventListener("click", openContactModal);
  });

  closeContactButtons.forEach(function (button) {
    button.addEventListener("click", closeContactModal);
  });

  if (contactModal) {
    contactModal.addEventListener("click", function (event) {
      if (event.target === contactModal) closeContactModal();
    });
  }

  if (contactForm) {
    contactForm.addEventListener("submit", function (event) {
      event.preventDefault();
      const data = new FormData(contactForm);
      const subject = encodeURIComponent("Nuevo proyecto — " + (data.get("projectType") || "Consulta"));
      const body = encodeURIComponent(
        "Nombre: " + (data.get("name") || "") + "\n" +
        "Correo: " + (data.get("email") || "") + "\n" +
        "Tipo de proyecto: " + (data.get("projectType") || "") + "\n" +
        "Presupuesto: " + (data.get("budget") || "") + "\n\n" +
        "Idea:\n" + (data.get("message") || "")
      );
      window.location.href = "mailto:hola@bastianmunoz.com?subject=" + subject + "&body=" + body;
    });
  }

  /* ============================================================
     EFECTOS DEL PERFIL
     ============================================================ */

  const profileManifesto = document.querySelector("[data-profile-manifesto]");
  let profileManifestoReady = false;

  function playProfileManifesto() {
    if (!profileManifesto || typeof gsap === "undefined" || typeof Splitting === "undefined") return;
    if (!profileManifestoReady) {
      Splitting({ target: profileManifesto, by: "chars" });
      profileManifestoReady = true;
    }
    const chars = profileManifesto.querySelectorAll(".char");
    gsap.killTweensOf(chars);
    gsap.fromTo(chars,
      { scaleY: 0, opacity: 0, transformOrigin: "50% 100%" },
      { scaleY: 1, opacity: 1, duration: .55, ease: "power3.out", stagger: .012 }
    );
  }

  const scrambleAlphabet = "abcdefghijklmnopqrstuvwxyz!@#$%&*-_+=<>".split("");
  const profileScrambleItems = document.querySelectorAll("[data-profile-scramble]");

  profileScrambleItems.forEach(function (item) {
    item.dataset.originalText = item.textContent;
  });

  function playProfileScramble(item) {
    const original = item.dataset.originalText || item.textContent;
    let frame = 0;
    const total = 12;
    const timer = window.setInterval(function () {
      item.textContent = original.split("").map(function (char, index) {
        if (char === " ") return " ";
        return index < (frame / total) * original.length
          ? original[index]
          : scrambleAlphabet[Math.floor(Math.random() * scrambleAlphabet.length)];
      }).join("");
      frame += 1;
      if (frame > total) {
        window.clearInterval(timer);
        item.textContent = original;
      }
    }, 45);
  }

  const profileScroll = document.querySelector(".profile-modal-scroll");
  if (profileScroll && "IntersectionObserver" in window) {
    const profileObserver = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) playProfileScramble(entry.target);
      });
    }, { root: profileScroll, threshold: .65 });
    profileScrambleItems.forEach(function (item) { profileObserver.observe(item); });
  }

  openProfileButtons.forEach(function (button) {
    button.addEventListener("click", function () {
      window.setTimeout(playProfileManifesto, 70);
    });
  });

  /* ============================================================
     TECLA ESCAPE
     ============================================================ */

  document.addEventListener("keydown", function (event) {
    if (event.key === "Escape") {
      closeProfileModal();
      closeContactModal();
      closeMobileMenu();
    }
  });
});
document.addEventListener("DOMContentLoaded", function () {
  const modal = document.querySelector("#profileModal");
  const modalScroll = modal?.querySelector(".profile-modal-scroll");

  if (!modal || !modalScroll) return;

  let profileEffectsCreated = false;

  function createProfileEffects() {
    if (profileEffectsCreated) return;
    if (typeof window.gsap === "undefined") return;
    if (typeof window.ScrollTrigger === "undefined") return;

    gsap.registerPlugin(ScrollTrigger);

    if (typeof window.Splitting === "function") {
      Splitting({
        target: modal.querySelectorAll(
          ".profile-manifesto-text, .profile-process-title"
        ),
        by: "chars"
      });
    }

    const manifestoCharacters = modal.querySelectorAll(
      ".profile-manifesto-text .char"
    );

    if (manifestoCharacters.length) {
      gsap.fromTo(
        manifestoCharacters,
        {
          opacity: 0.12,
          rotateX: -75,
          yPercent: 45
        },
        {
          opacity: 1,
          rotateX: 0,
          yPercent: 0,
          stagger: 0.012,
          ease: "power2.out",
          scrollTrigger: {
            trigger: ".profile-manifesto-text",
            scroller: modalScroll,
            start: "top 80%",
            end: "bottom 42%",
            scrub: 1
          }
        }
      );
    }

    modal.querySelectorAll(".profile-process-title").forEach(function (title) {
      const characters = title.querySelectorAll(".char");

      if (!characters.length) return;

      gsap.fromTo(
        characters,
        {
          opacity: 0.12
        },
        {
          opacity: 1,
          stagger: 0.035,
          ease: "none",
          scrollTrigger: {
            trigger: title,
            scroller: modalScroll,
            start: "top 86%",
            end: "bottom 55%",
            scrub: 0.8
          }
        }
      );
    });

    modal.querySelectorAll(".profile-experience-list article").forEach(
      function (item) {
        gsap.fromTo(
          item,
          {
            opacity: 0,
            y: 28
          },
          {
            opacity: 1,
            y: 0,
            duration: 0.65,
            ease: "power2.out",
            scrollTrigger: {
              trigger: item,
              scroller: modalScroll,
              start: "top 90%",
              once: true
            }
          }
        );
      }
    );

    modal.querySelectorAll(".profile-skill-group").forEach(function (item) {
      gsap.fromTo(
        item,
        {
          opacity: 0,
          y: 24
        },
        {
          opacity: 1,
          y: 0,
          duration: 0.6,
          ease: "power2.out",
          scrollTrigger: {
            trigger: item,
            scroller: modalScroll,
            start: "top 90%",
            once: true
          }
        }
      );
    });

    profileEffectsCreated = true;
  }

  document.querySelectorAll("[data-open-profile]").forEach(function (button) {
    button.addEventListener("click", function () {
      window.setTimeout(function () {
        createProfileEffects();
        ScrollTrigger.refresh();
      }, 420);
    });
  });
});