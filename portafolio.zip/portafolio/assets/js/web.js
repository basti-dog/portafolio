document.addEventListener("DOMContentLoaded", function () {
  const projects = Array.from(document.querySelectorAll("[data-web-project]"));

  projects.forEach(function (project) {
    const media = project.querySelector("[data-web-media]");
    const images = Array.from(project.querySelectorAll(".web-project-images img"));
    const dotsWrap = project.querySelector(".web-project-dots");

    if (!media || images.length < 2) return;

    let activeIndex = 0;
    let cycleTimer = null;
    let leaveTimer = null;

    media.classList.add("is-ready");

    function setActive(index) {
      const nextIndex = Math.max(0, Math.min(images.length - 1, index));
      activeIndex = nextIndex;

      images.forEach(function (image, imageIndex) {
        const isActive = imageIndex === activeIndex;
        image.classList.toggle("is-active", isActive);
        image.setAttribute("aria-hidden", String(!isActive));
      });

      if (dotsWrap) {
        Array.from(dotsWrap.children).forEach(function (dot, dotIndex) {
          const isActive = dotIndex === activeIndex;
          dot.classList.toggle("is-active", isActive);
          dot.setAttribute("aria-pressed", String(isActive));
        });
      }

      media.style.setProperty("--active-view", String(activeIndex + 1));
      media.setAttribute("data-active-view", String(activeIndex + 1).padStart(2, "0"));
    }

    function stopCycle() {
      if (cycleTimer !== null) {
        window.clearInterval(cycleTimer);
        cycleTimer = null;
      }
      media.classList.remove("is-cycling");
    }

    function startCycle() {
      stopCycle();
      media.classList.add("is-cycling");
      cycleTimer = window.setInterval(function () {
        setActive((activeIndex + 1) % images.length);
      }, 950);
    }

    if (dotsWrap) {
      dotsWrap.innerHTML = "";
      images.forEach(function (_, index) {
        const dot = document.createElement("button");
        dot.type = "button";
        dot.className = "web-project-dot";
        dot.setAttribute("aria-label", "Mostrar vista " + (index + 1));
        dot.addEventListener("click", function (event) {
          event.preventDefault();
          event.stopPropagation();
          stopCycle();
          setActive(index);
        });
        dotsWrap.appendChild(dot);
      });
    }

    media.addEventListener("pointerenter", function () {
      if (leaveTimer !== null) window.clearTimeout(leaveTimer);
      startCycle();
    });

    media.addEventListener("pointermove", function (event) {
      if (event.pointerType === "touch") return;

      const rect = media.getBoundingClientRect();
      const relativeX = Math.min(Math.max(event.clientX - rect.left, 0), rect.width - 1);
      const index = Math.floor((relativeX / rect.width) * images.length);

      stopCycle();
      setActive(index);
    });

    media.addEventListener("pointerleave", function () {
      stopCycle();
      leaveTimer = window.setTimeout(function () {
        setActive(0);
      }, 220);
    });

    media.addEventListener("click", function (event) {
      if (event.target.closest(".web-project-dot")) return;
      stopCycle();
      setActive((activeIndex + 1) % images.length);
    });

    media.setAttribute("tabindex", "0");
    media.setAttribute("role", "group");
    media.setAttribute("aria-label", "Galería de vistas del proyecto. Usa las flechas izquierda y derecha.");

    media.addEventListener("keydown", function (event) {
      if (event.key === "ArrowRight") {
        event.preventDefault();
        stopCycle();
        setActive((activeIndex + 1) % images.length);
      }

      if (event.key === "ArrowLeft") {
        event.preventDefault();
        stopCycle();
        setActive((activeIndex - 1 + images.length) % images.length);
      }
    });

    setActive(0);
  });
});
