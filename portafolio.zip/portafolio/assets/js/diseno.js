(function () {
  "use strict";

  document.addEventListener("DOMContentLoaded", function () {
    const animeAvailable = typeof window.anime === "function";
    const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    // Compatibilidad con Anime.js 2 y 3.
    function staggerDelay(step) {
      return function (_el, index) { return index * step; };
    }

    const projects = {
      elevare: {
        group: "social",
        type: "gallery",
        title: "Clínica Elevare",
        category: "Contenido digital · Medicina estética",
        year: "2026",
        description: "Dirección visual para una comunicación clínica, cercana y premium.",
        items: [
          { label: "Piezas", src: "assets/img/foto2.jpg", alt: "Pieza de Clínica Elevare" },
          { label: "Sistema", src: "assets/img/diseno.svg", alt: "Sistema gráfico", contain: true },
          { label: "Aplicaciones", src: "assets/img/fotocarneh.jpg", alt: "Aplicación digital" },
          { label: "Adaptaciones", src: "assets/img/web.svg", alt: "Adaptación digital", contain: true }
        ]
      },
      ceon: {
        group: "social",
        type: "gallery",
        title: "Centro Ceón",
        category: "Contenido digital · Odontología",
        year: "2026",
        description: "Sistema de contenidos educativos y corporativos para distintas especialidades odontológicas.",
        items: [
          { label: "Sistema", src: "assets/img/diseno.svg", alt: "Sistema visual", contain: true },
          { label: "Publicaciones", src: "assets/img/foto2.jpg", alt: "Publicación" },
          { label: "Historias", src: "assets/img/web.svg", alt: "Historia", contain: true },
          { label: "Campaña", src: "assets/img/fotocarneh.jpg", alt: "Campaña" }
        ]
      },
      riveros: {
        group: "social",
        type: "gallery",
        title: "Letreros Riveros",
        category: "Contenido digital · Industria y señalética",
        year: "2026",
        description: "Contenido orientado a trayectoria, experiencia y seguridad industrial.",
        items: [
          { label: "Campaña", src: "assets/img/fotocarneh.jpg", alt: "Campaña industrial" },
          { label: "Sistema", src: "assets/img/web.svg", alt: "Sistema gráfico", contain: true },
          { label: "Publicaciones", src: "assets/img/foto2.jpg", alt: "Publicación" },
          { label: "Recursos", src: "assets/img/diseno.svg", alt: "Recursos visuales", contain: true }
        ]
      },
      "bastian-brand": {
        group: "branding",
        type: "narrative",
        title: "Bastián Muñoz",
        category: "Identidad y branding · Rebranding personal",
        year: "2026",
        description: "Sistema visual construido desde la idea del portador de luz, la exploración y la búsqueda de una forma propia.",
        items: [
          { label: "Concepto", title: "Una identidad que nace de la búsqueda.", text: "El concepto conecta conocimiento, amanecer, transformación y carácter.", src: "assets/img/foto2.jpg", alt: "Concepto del rebranding" },
          { label: "Símbolo", title: "La estrella y la B se convierten en sistema.", text: "El símbolo funciona como firma, señal y elemento modular.", src: "assets/img/isologo-b-01.png", alt: "Isologo de Bastián Muñoz", contain: true },
          { label: "Paleta", title: "Neutros, arena y contraste.", text: "Una paleta sobria que permite mantener una presencia editorial y flexible.", src: "assets/img/diseno.svg", alt: "Paleta y sistema visual", contain: true },
          { label: "Aplicaciones", title: "El sistema se adapta sin perder identidad.", text: "La marca se extiende a presentaciones, redes y experiencia digital.", src: "assets/img/web.svg", alt: "Aplicaciones de marca", contain: true }
        ]
      },
      "buen-diablo": {
        group: "branding",
        type: "narrative",
        title: "El Buen Diablo",
        category: "Identidad y branding · Sistema visual",
        year: "2026",
        description: "Universo gráfico experimental donde identidad, ilustración y relato conviven dentro de un mismo lenguaje.",
        items: [
          { label: "Origen", title: "Una identidad nacida desde el dibujo.", text: "El proyecto combina gesto manual, contraste y una actitud más libre.", src: "assets/img/fotocarneh.jpg", alt: "Origen del proyecto" },
          { label: "Marca", title: "Una firma reconocible y flexible.", text: "El sistema puede convivir con ilustraciones, etiquetas y piezas editoriales.", src: "assets/img/isologo-w-01.png", alt: "Marca El Buen Diablo", contain: true, dark: true },
          { label: "Lenguaje", title: "Textura, personajes y contraste.", text: "La identidad se amplía mediante recursos gráficos que mantienen una voz común.", src: "assets/img/diseno.svg", alt: "Lenguaje gráfico", contain: true },
          { label: "Aplicaciones", title: "El universo crece con cada pieza.", text: "Cada aplicación suma información sin perder el carácter inicial.", src: "assets/img/foto2.jpg", alt: "Aplicaciones de marca" }
        ]
      },
      "manual-marca": {
        group: "narratives",
        type: "narrative",
        title: "Manual de marca",
        category: "Manuales y presentaciones · Identidad",
        year: "2026",
        description: "Un documento que ordena el uso de la identidad y convierte sus decisiones en reglas claras.",
        items: [
          { label: "Portada", title: "El sistema comienza con una idea clara.", text: "La apertura presenta el carácter y el propósito de la identidad.", src: "assets/img/foto2.jpg", alt: "Portada del manual" },
          { label: "Construcción", title: "Proporciones y reglas de uso.", text: "Retícula, márgenes, reducciones y versiones para mantener consistencia.", src: "assets/img/isologo-b-01.png", alt: "Construcción del símbolo", contain: true },
          { label: "Color", title: "Una paleta preparada para distintos soportes.", text: "Valores, combinaciones y contrastes se organizan para evitar usos incorrectos.", src: "assets/img/diseno.svg", alt: "Paleta de color", contain: true },
          { label: "Aplicaciones", title: "Las reglas se prueban en contexto.", text: "Piezas digitales, documentos y soportes muestran cómo vive la marca.", src: "assets/img/web.svg", alt: "Aplicaciones del manual", contain: true }
        ]
      },
      presentacion: {
        group: "narratives",
        type: "narrative",
        title: "Presentación visual",
        category: "Manuales y presentaciones · Presentación corporativa",
        year: "2026",
        description: "Una narrativa de láminas que transforma información extensa en un recorrido visual claro.",
        items: [
          { label: "Inicio", title: "Una apertura que define el tono.", text: "La portada presenta el tema y prepara el ritmo de la exposición.", src: "assets/img/fotocarneh.jpg", alt: "Portada de presentación" },
          { label: "Jerarquía", title: "Cada lámina responde una pregunta.", text: "Titulares, cifras y recursos visuales organizan la lectura.", src: "assets/img/diseno.svg", alt: "Jerarquía de contenido", contain: true },
          { label: "Ritmo", title: "Variación sin perder continuidad.", text: "Cambios de escala y composición evitan la monotonía.", src: "assets/img/foto2.jpg", alt: "Lámina de presentación" },
          { label: "Cierre", title: "La última idea queda visible.", text: "El cierre resume el mensaje y dirige la siguiente acción.", src: "assets/img/web.svg", alt: "Cierre de presentación", contain: true }
        ]
      },
      documento: {
        group: "narratives",
        type: "narrative",
        title: "Documento editorial",
        category: "Manuales y presentaciones · Documento",
        year: "2026",
        description: "Diagramación y recursos visuales para transformar contenido complejo en una lectura simple.",
        items: [
          { label: "Estructura", title: "El contenido se ordena antes de diseñarse.", text: "Capítulos, niveles y recorridos permiten anticipar la lectura.", src: "assets/img/web.svg", alt: "Estructura editorial", contain: true },
          { label: "Retícula", title: "La retícula sostiene la consistencia.", text: "Columnas, márgenes y espacios crean un ritmo estable.", src: "assets/img/diseno.svg", alt: "Retícula editorial", contain: true },
          { label: "Contenido", title: "Texto e imagen comparten jerarquía.", text: "El sistema prioriza comprensión, contraste y respiración.", src: "assets/img/foto2.jpg", alt: "Página editorial" },
          { label: "Resultado", title: "Una lectura más clara y memorable.", text: "El documento final mantiene unidad incluso en contenidos extensos.", src: "assets/img/fotocarneh.jpg", alt: "Documento terminado" }
        ]
      }
    };

    function setupExperience(experience) {
      const slides = Array.from(experience.querySelectorAll("[data-client-slide]"));
      const previousButton = experience.querySelector("[data-client-prev]");
      const nextButton = experience.querySelector("[data-client-next]");
      const currentLabel = experience.querySelector("[data-client-current]");
      let currentIndex = 0;
      let animating = false;

      function setVisible(slide, visible) {
        slide.classList.toggle("is-current", visible);
        slide.setAttribute("aria-hidden", String(!visible));
      }

      function updateCounter() {
        if (currentLabel) currentLabel.textContent = String(currentIndex + 1).padStart(2, "0");
      }

      function showSlide(nextIndex, direction) {
        if (animating || nextIndex === currentIndex) return;
        const currentSlide = slides[currentIndex];
        const nextSlide = slides[nextIndex];
        const currentParts = [currentSlide.querySelector(".client-slide-copy"), currentSlide.querySelector(".client-slide-image")];
        const nextParts = [nextSlide.querySelector(".client-slide-copy"), nextSlide.querySelector(".client-slide-image")];
        const offset = direction > 0 ? 84 : -84;

        animating = true;
        setVisible(nextSlide, true);

        if (!animeAvailable || reduceMotion) {
          setVisible(currentSlide, false);
          currentIndex = nextIndex;
          updateCounter();
          animating = false;
          return;
        }

        window.anime.set(nextParts, { translateY: offset, opacity: 0 });
        window.anime.timeline({
          easing: "easeInOutQuart",
          complete: function () {
            setVisible(currentSlide, false);
            window.anime.set(currentParts.concat(nextParts), { translateY: 0, opacity: 1, scale: 1 });
            currentIndex = nextIndex;
            updateCounter();
            animating = false;
          }
        })
          .add({ targets: currentParts, translateY: -offset, opacity: 0, duration: 520, delay: staggerDelay(45) }, 0)
          .add({ targets: nextParts, translateY: 0, opacity: 1, duration: 760, delay: staggerDelay(80) }, 260);
      }

      function move(step) {
        showSlide((currentIndex + step + slides.length) % slides.length, step);
      }

      previousButton?.addEventListener("click", function () { move(-1); });
      nextButton?.addEventListener("click", function () { move(1); });
      updateCounter();
    }

    document.querySelectorAll("[data-clients-experience], [data-portfolio-experience]").forEach(setupExperience);

    const modal = document.querySelector("[data-project-modal]");
    if (!modal) return;

    const panel = modal.querySelector(".client-modal-panel");
    const scroll = modal.querySelector("[data-project-modal-scroll]");
    const title = modal.querySelector("[data-modal-title]");
    const category = modal.querySelector("[data-modal-category]");
    const year = modal.querySelector("[data-modal-year]");
    const description = modal.querySelector("[data-modal-description]");
    const content = modal.querySelector("[data-modal-content]");
    const closeButton = modal.querySelector("[data-close-project]");
    const prevButton = modal.querySelector("[data-modal-prev]");
    const nextButton = modal.querySelector("[data-modal-next]");
    let activeKey = "elevare";
    let lastTrigger = null;
    let observer = null;

    function groupKeys(key) {
      const group = projects[key].group;
      return Object.keys(projects).filter(function (projectKey) { return projects[projectKey].group === group; });
    }

    function renderGallery(project) {
      content.className = "project-modal-content project-modal-content--gallery";
      content.innerHTML = '<div class="client-modal-gallery">' + project.items.map(function (item) {
        return '<figure class="' + (item.contain ? 'is-contain' : '') + '"><img src="' + item.src + '" alt="' + item.alt + '"><figcaption>' + item.label + '</figcaption></figure>';
      }).join("") + "</div>";
    }

    function renderNarrative(project) {
      content.className = "project-modal-content project-modal-content--narrative";
      content.innerHTML = '<div class="modal-narrative-layout">' +
        '<aside class="modal-narrative-sticky"><div class="modal-narrative-word" data-modal-word>' + project.items[0].label + '</div><div class="modal-narrative-progress"><span data-modal-current>01</span><span></span><span>' + String(project.items.length).padStart(2, "0") + '</span></div></aside>' +
        '<div class="modal-narrative-list">' + project.items.map(function (item, index) {
          return '<article class="modal-narrative-case" data-modal-case data-label="' + item.label + '" data-number="' + String(index + 1).padStart(2, "0") + '">' +
            '<header><span>' + item.label + '</span><h3>' + item.title + '</h3><p>' + item.text + '</p></header>' +
            '<figure class="' + (item.contain ? 'is-contain' : '') + (item.dark ? ' is-dark' : '') + '"><img src="' + item.src + '" alt="' + item.alt + '"></figure>' +
          '</article>';
        }).join("") + '</div></div>';
      initNarrativeObserver();
    }

    function replaceWord(wordElement, label, numberElement, number) {
      if (!wordElement || wordElement.textContent.trim() === label) return;
      const oldLetters = Array.from(wordElement.querySelectorAll("span"));
      function apply() {
        wordElement.textContent = label;
        if (typeof window.charming === "function") window.charming(wordElement);
        if (numberElement) numberElement.textContent = number;
        const letters = wordElement.querySelectorAll("span");
        if (animeAvailable && !reduceMotion) {
          window.anime({ targets: letters, translateY: ["110%", "0%"], opacity: [0, 1], delay: staggerDelay(28), duration: 620, easing: "easeOutExpo" });
        }
      }
      if (animeAvailable && !reduceMotion && oldLetters.length) {
        window.anime({ targets: oldLetters, translateY: ["0%", "-110%"], opacity: [1, 0], delay: staggerDelay(18), duration: 280, easing: "easeInQuad", complete: apply });
      } else apply();
    }

    function initNarrativeObserver() {
      if (observer) observer.disconnect();
      const word = content.querySelector("[data-modal-word]");
      const current = content.querySelector("[data-modal-current]");
      const cases = Array.from(content.querySelectorAll("[data-modal-case]"));
      if (!word || !cases.length) return;
      if (typeof window.charming === "function") window.charming(word);
      observer = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) replaceWord(word, entry.target.dataset.label, current, entry.target.dataset.number);
        });
      }, { root: scroll, threshold: 0.55 });
      cases.forEach(function (item) { observer.observe(item); });
    }

    function renderProject(key) {
      const project = projects[key];
      if (!project) return;
      activeKey = key;
      title.textContent = project.title;
      category.textContent = project.category;
      year.textContent = project.year;
      description.textContent = project.description;
      if (project.type === "narrative") renderNarrative(project); else renderGallery(project);
    }

    function openProject(key, trigger) {
      lastTrigger = trigger || document.activeElement;
      renderProject(key);
      scroll.scrollTop = 0;

      // La apertura del modal se controla solo con CSS para evitar que
      // una falla de Anime.js deje el body bloqueado con el panel invisible.
      modal.classList.add("is-open");
      modal.setAttribute("aria-hidden", "false");
      document.body.classList.add("client-modal-open");

      window.requestAnimationFrame(function () {
        modal.classList.add("is-visible");
      });

      window.setTimeout(function () {
        closeButton.focus();
      }, reduceMotion ? 0 : 650);
    }

    function closeProject() {
      modal.classList.remove("is-visible");

      window.setTimeout(function () {
        modal.classList.remove("is-open");
        modal.setAttribute("aria-hidden", "true");
        document.body.classList.remove("client-modal-open");
        if (observer) observer.disconnect();
        if (lastTrigger && typeof lastTrigger.focus === "function") {
          lastTrigger.focus();
        }
      }, reduceMotion ? 0 : 520);
    }

    function moveProject(step) {
      const keys = groupKeys(activeKey);
      const index = keys.indexOf(activeKey);
      const nextKey = keys[(index + step + keys.length) % keys.length];
      if (animeAvailable && !reduceMotion) {
        window.anime({ targets: content, translateY: -30, opacity: 0, duration: 250, easing: "easeInQuad", complete: function () {
          renderProject(nextKey);
          scroll.scrollTop = 0;
          window.anime({ targets: content, translateY: [40, 0], opacity: [0, 1], duration: 620, easing: "easeOutExpo" });
        }});
      } else {
        renderProject(nextKey);
        scroll.scrollTop = 0;
      }
    }

    document.querySelectorAll("[data-open-client], [data-open-project]").forEach(function (button) {
      button.addEventListener("click", function () {
        openProject(button.dataset.openClient || button.dataset.openProject, button);
      });
    });

    closeButton.addEventListener("click", closeProject);
    prevButton.addEventListener("click", function () { moveProject(-1); });
    nextButton.addEventListener("click", function () { moveProject(1); });
    document.addEventListener("keydown", function (event) {
      if (!modal.classList.contains("is-open")) return;
      if (event.key === "Escape") closeProject();
      if (event.key === "ArrowLeft") moveProject(-1);
      if (event.key === "ArrowRight") moveProject(1);
    });
  });
})();
